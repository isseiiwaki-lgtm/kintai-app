
import os
import pickle
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Define scopes and paths
SCOPES = ['https://www.googleapis.com/auth/youtube.upload', 'https://www.googleapis.com/auth/youtube.readonly', 'https://www.googleapis.com/auth/drive.file']
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CLIENT_SECRET_FILE = os.path.join(BASE_DIR, '..', 'config', 'client_secret.json')
TOKEN_FILE = os.path.join(BASE_DIR, '..', 'config', 'token.pickle')

def main():
    print("========================================================")
    print(" Googleアカウント 再認証ツール")
    print("========================================================")
    print("これからブラウザが開きます。")
    print("使用するGoogleアカウントを選択し、すべての権限を「許可」してください。")
    print("\n※「このアプリはGoogleによって確認されていません」と出た場合は、")
    print("  「詳細」→「(安全ではないページ)に移動」をクリックして進めてください。\n")
    input("Enter キーを押すとブラウザが開きます...")
    
    print("\nStarting automatic authentication...")
    
    if not os.path.exists(CLIENT_SECRET_FILE):
        print(f"Error: Client secret not found at {CLIENT_SECRET_FILE}")
        return

    try:
        flow = InstalledAppFlow.from_client_secrets_file(
            CLIENT_SECRET_FILE, SCOPES)
        
        # This will open a browser window on the user's machine
        print("Opening browser for authentication...")
        print("★黒い画面は閉じないでください！認証が終わるまで待機しています...★")
        
        # Explicitly set the redirect_uri to match what we expect (standardize on trailing slash or not)
        # Actually run_local_server sets it dynamically.
        # But for Web Client, we must be exact.
        # Let's try to force the redirect_uri match if possible, or just print what we need.
        expected_uri = "http://localhost:8080/"
        flow.redirect_uri = expected_uri
        
        print(f"\n【重要】Google Cloud Consoleの設定確認:")
        print(f"「承認済みのリダイレクト URI」に以下が設定されているか確認してください:")
        print(f"  {expected_uri}")
        print(f"  (末尾の / スラッシュも重要です！)\n")

        # Custom message with URL in case browser doesn't open
        auth_msg = "ブラウザが自動で開かない場合は、以下のURLをコピーしてブラウザに貼り付けてください:\n{url}"
        
        # Force port 8080
        creds = flow.run_local_server(port=8080, prompt='consent', authorization_prompt_message=auth_msg)
        
        # Save the credentials for the next run
        with open(TOKEN_FILE, 'wb') as token:
            pickle.dump(creds, token)
            
        print("\nSUCCESS: Authentication complete.")
        print(f"Token saved to: {TOKEN_FILE}")
        
        # Verify the connected channel
        try:
            print("\nChecking connected YouTube channel...")
            service = build('youtube', 'v3', credentials=creds)
            response = service.channels().list(mine=True, part='snippet').execute()
            if 'items' in response and len(response['items']) > 0:
                channel_title = response['items'][0]['snippet']['title']
                print(f"==========================================")
                print(f" 現在接続されているチャンネル: 【 {channel_title} 】")
                print(f"==========================================")
            else:
                print("⚠ チャンネル情報が取得できませんでした。YouTubeチャンネルが作成されていない可能性があります。")
        except Exception as e:
            print(f"Warning: Failed to verify channel name: {e}")
            
    except OSError as e:
        if e.errno == 98 or e.winerror == 10048:
            print(f"\nERROR: Port 8080 is already in use.")
            print("他のプログラム（または以前のこのツール）が8080ポートを使っている可能性があります。")
            print("黒い画面をすべて閉じてから、もう一度やり直してください。")
        else:
            print(f"\nERROR: System error: {e}")
    except Exception as e:
        print(f"\nERROR: Authentication failed: {e}")
        print("詳細エラーを確認してください。")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Fatal Error: {e}")
    
    # Keep window open if run directly
    pass
