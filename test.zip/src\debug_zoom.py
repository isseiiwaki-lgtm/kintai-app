
import os
import yaml
from services.zoom import ZoomClient
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load_secrets():
    with open(os.path.join(BASE_DIR, 'config', 'secrets.yaml'), 'r') as f:
        return yaml.safe_load(f)

def main():
    secrets = load_secrets()
    zoom_conf = secrets['zoom']
    
    client = ZoomClient(
        zoom_conf['account_id'],
        zoom_conf['client_id'],
        zoom_conf['client_secret']
    )
    
    print("Fetching recordings...")
    seven_days_ago = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
    meetings = client.get_recordings(user_id='me', from_date=seven_days_ago) # Use 'me' or fetch user
    
    if not meetings:
        print("No meetings found.")
        return

    # Sort
    meetings.sort(key=lambda x: x['start_time'])
    latest = meetings[-1]
    
    print(f"Latest Meeting: {latest.get('topic')} ({latest.get('start_time')})")
    
    import json
    with open('debug_output.json', 'w', encoding='utf-8') as f:
        json.dump(latest, f, indent=2, ensure_ascii=False)
        
    print("Saved to debug_output.json")

if __name__ == "__main__":
    main()
