import os
import yaml
import logging
from datetime import datetime
from .youtube import YouTubeClient
from .gemini import GeminiProcessor
from .drive import DriveClient

logger = logging.getLogger(__name__)

def load_secrets(base_dir):
    with open(os.path.join(base_dir, 'config', 'secrets.yaml'), 'r') as f:
        return yaml.safe_load(f)

def process_video_file(video_path, base_dir=None, video_title=None, transcript_path=None):
    if base_dir is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    
    if not os.path.exists(video_path):
        print(f"Error: File not found: {video_path}")
        return

    print(f"\n=== Starting Processing: {os.path.basename(video_path)} ===")
    logger.info(f"Processing started for: {video_path}")
    secrets = load_secrets(base_dir)

    # 1. YouTube Upload
    try:
        print("\n--- Step 1: YouTube Upload ---")
        client_secret = os.path.join(base_dir, 'config', 'client_secret.json')
        token_file = os.path.join(base_dir, 'config', 'token.pickle')
        
        yt = YouTubeClient(client_secret, token_file=token_file)
        
        # Use provided title or fallback to default
        final_title = video_title if video_title else f"Meeting Log {datetime.now().strftime('%Y-%m-%d')}"
        
        video_id = yt.upload_video(
            video_path, 
            title=final_title,
            description="Automated upload via Hearing App"
        )
        video_url = f"https://youtu.be/{video_id}"
        print(f"Success! URL: {video_url}")
        logger.info(f"YouTube Upload Success: {video_url}")
    except Exception as e:
        print(f"YouTube Failed: {e}")
        logger.error(f"YouTube Failed: {e}")
        return

    # 2. Gemini Processing
    try:
        print("\n--- Step 2: Gemini Minutes ---")
        gemini = GeminiProcessor(secrets['google']['gemini_api_key'])
        
        minutes_text = ""
        
        # Priority 1: Use Transcript if available
        if transcript_path and os.path.exists(transcript_path):
            print(f"Using Transcript file: {transcript_path}")
            logger.info(f"Using Transcript: {transcript_path}")
            try:
                # Zoom VTT/TXT reading
                with open(transcript_path, 'r', encoding='utf-8') as f:
                    transcript_content = f.read()
                
                # Direct text generation (Mocking process_video interface or calling generate_content directly)
                # Since GeminiProcessor.process_video handles "upload", we should bypass it or add a method.
                # For simplicity, we'll access the model directly here or add a method to GeminiProcessor.
                # Let's add a helper here for now.
                prompt = "以下の会議の文字起こしテキストから、詳細な議事録を作成してください。\n\n" + transcript_content
                response = gemini.model.generate_content(prompt)
                minutes_text = response.text
                print("Generated minutes from transcript text.")
                
            except Exception as e:
                print(f"Transcript processing failed: {e}")
                logger.error(f"Transcript failed: {e}")
                # Fallback to video/audio? No, if user provided transcript, stay with it or fail.
                # But let's fallback to audio extraction just in case transcript was empty/bad.
                print("Falling back to audio extraction...")
                minutes_text = None

        # Priority 2: Audio Extraction (Fallback or Default)
        if not minutes_text:
            # Audio Extraction (to save tokens)
            print("Extracting audio to save AI tokens...")
            audio_path = video_path.replace('.mp4', '.mp3')
            
            try:
                import imageio_ffmpeg
                import subprocess
                ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
                print(f"Using FFMPEG: {ffmpeg_exe}")
                
                # -y: overwrite, -vn: no video, -b:a 32k: low bitrate audio
                cmd = [ffmpeg_exe, "-y", "-i", video_path, "-vn", "-b:a", "32k", audio_path]
                
                # Capture output for debugging if needed
                result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                
                if result.returncode != 0:
                    raise RuntimeError(f"FFMPEG failed (code {result.returncode}):\n{result.stderr}")
                    
                print(f"Audio extracted: {audio_path}")
                target_file = audio_path
            except Exception as e:
                import traceback
                error_details = traceback.format_exc()
                print(f"Audio extraction failed: {e}")
                logger.warning(f"Audio extraction failed: {e}\n{error_details}")
                target_file = video_path

            minutes_text = gemini.process_video(target_file)
            
            # Cleanup audio file
            if target_file == audio_path and os.path.exists(audio_path):
                os.remove(audio_path)
                print("Temporary audio file removed.")
        
        # Save Output
        output_dir = os.path.join(base_dir, 'output')
        os.makedirs(output_dir, exist_ok=True)
        
        filename = f"MINUTES_{os.path.basename(video_path)}.md"
        output_path = os.path.join(output_dir, filename)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(f"# Meeting Minutes\n\nYouTube: {video_url}\n\n{minutes_text}")
            
        print(f"\nSUCCESS! Minutes saved to:\n  {output_path}")
        logger.info(f"Minutes saved to: {output_path}")

        # 3. Google Drive Upload
        try:
            print("\n--- Step 3: Google Drive Upload ---")
            import pickle
            from google.auth.transport.requests import Request
            
            drive_folder_id = secrets.get('google', {}).get('drive_folder_id')
            token_file = os.path.join(base_dir, 'config', 'token.pickle')
            
            creds = None
            if os.path.exists(token_file):
                with open(token_file, 'rb') as token:
                    creds = pickle.load(token)
            
            # トークンが期限切れの場合はリフレッシュ
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                    # リフレッシュ後のトークンを保存
                    with open(token_file, 'wb') as token:
                        pickle.dump(creds, token)
                    logger.info("Drive用トークンをリフレッシュしました。")
                except Exception as e:
                    logger.error(f"Drive用トークンのリフレッシュに失敗: {e}")
                    creds = None
            
            if creds and creds.valid:
                drive = DriveClient(credentials=creds)
                uploaded_link = drive.upload_file(output_path, folder_id=drive_folder_id)
                if uploaded_link:
                    print(f"Uploaded to Drive: {uploaded_link}")
                    logger.info(f"Drive Upload Success: {uploaded_link}")
            else:
                print("Drive Upload Skipped: 認証情報が無効です（再認証.pyを実行してください）")
                logger.warning("Drive Upload Skipped: Invalid credentials")

        except Exception as e:
            print(f"Drive Upload Failed: {e}")
            logger.error(f"Drive Upload Failed: {e}")
            
    except Exception as e:
        print(f"Gemini Failed: {e}")
        logger.error(f"Gemini Failed: {e}")
