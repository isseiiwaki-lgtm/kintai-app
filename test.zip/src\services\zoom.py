import requests
import base64
import time
import logging

class ZoomClient:
    def __init__(self, account_id, client_id, client_secret):
        self.account_id = account_id
        self.client_id = client_id
        self.client_secret = client_secret
        self.base_url = "https://api.zoom.us/v2"
        self.token_url = "https://zoom.us/oauth/token"
        self.access_token = None
        self.token_expires_at = 0
        self.logger = logging.getLogger('ZoomClient')

    def _get_access_token(self):
        if self.access_token and time.time() < self.token_expires_at:
            return self.access_token

        auth_header = base64.b64encode(f"{self.client_id}:{self.client_secret}".encode()).decode()
        headers = {"Authorization": f"Basic {auth_header}"}
        params = {"grant_type": "account_credentials", "account_id": self.account_id}

        try:
            response = requests.post(self.token_url, headers=headers, params=params)
            response.raise_for_status()
            data = response.json()
            self.access_token = data["access_token"]
            self.token_expires_at = time.time() + data["expires_in"] - 60
            return self.access_token
        except Exception as e:
            self.logger.error(f"Zoom Auth Failed: {e}")
            raise

    def get_recordings(self, user_id="me", from_date=None, to_date=None):
        """Get all recordings for a user."""
        token = self._get_access_token()
        url = f"{self.base_url}/users/{user_id}/recordings"
        headers = {"Authorization": f"Bearer {token}"}
        params = {}
        if from_date:
            params['from'] = from_date
        if to_date:
            params['to'] = to_date
        
        # Get from past 30 days default
        try:
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            return response.json().get('meetings', [])
        except Exception as e:
            self.logger.error(f"List Recordings Failed: {e}")
            raise

    def download_file(self, download_url, save_path):
        """Download file with Bearer token."""
        token = self._get_access_token()
        headers = {"Authorization": f"Bearer {token}"}
        
        # Zoom requires access_token as query param for download_url often, even with Bearer header
        if '?' in download_url:
            final_url = f"{download_url}&access_token={token}"
        else:
            final_url = f"{download_url}?access_token={token}"

        self.logger.info(f"Downloading to {save_path}...")
        try:
            with requests.get(final_url, headers=headers, stream=True) as r:
                r.raise_for_status()
                with open(save_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
            self.logger.info("Download complete.")
            return save_path
        except Exception as e:
            self.logger.error(f"Download Failed: {e}")
            raise
