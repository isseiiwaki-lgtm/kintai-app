import os
import subprocess
import logging
import threading
from fastapi import FastAPI, BackgroundTasks
from fastapi.responses import HTMLResponse, PlainTextResponse, JSONResponse

app = FastAPI()

# ロガー設定
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('server')

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROCESS_SCRIPT = os.path.join(BASE_DIR, 'src', 'main.py')
LOG_FILE = os.path.join(BASE_DIR, 'process.log')

# グローバルな実行状態フラグ
is_running = False
status_lock = threading.Lock()

def run_script():
    global is_running
    with status_lock:
        if is_running:
            return
        is_running = True
        
    logger.info("Received Remote Trigger. Starting main.py...")
    try:
        # Run using the same python interpreter, capture output
        result = subprocess.run(
            ["python", PROCESS_SCRIPT],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace'
        )
        # エラーをprocess.logに書き込む
        if result.returncode != 0 or result.stderr:
            with open(LOG_FILE, 'a', encoding='utf-8') as f:
                f.write(f"\n[SERVER ERROR] returncode={result.returncode}\n")
                if result.stderr:
                    f.write(f"[STDERR]\n{result.stderr}\n")
                if result.stdout:
                    f.write(f"[STDOUT]\n{result.stdout}\n")
        logger.info(f"Script finished. returncode={result.returncode}")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f"\n[SERVER EXCEPTION] {e}\n")
    finally:
        with status_lock:
            is_running = False

@app.get("/", response_class=HTMLResponse)
async def home():
    html_content = """
    <!DOCTYPE html>
    <html lang="ja">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>議事録アップくん リモコン v2</title>
        <style>
            body { 
                font-family: 'Helvetica Neue', Arial, sans-serif; 
                display: flex; 
                flex-direction: column;
                align-items: center; 
                justify-content: center; 
                height: 100vh; 
                margin: 0; 
                background-color: #f0f2f5; 
                color: #333;
            }
            h1 { margin-bottom: 5px; }
            .subtitle { font-size: 14px; color: #666; margin-bottom: 30px; text-align: center; }
            .btn {
                background-color: #007bff;
                color: white;
                border: none;
                border-radius: 50%;
                width: 200px;
                height: 200px;
                font-size: 24px;
                font-weight: bold;
                cursor: pointer;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                transition: transform 0.1s, box-shadow 0.1s;
                display: flex;
                align-items: center;
                justify-content: center;
                text-align: center;
            }
            .btn:active {
                transform: scale(0.95);
                box-shadow: 0 2px 10px rgba(0,0,0,0.2);
                background-color: #0056b3;
            }
            .btn:disabled {
                background-color: #cccccc !important;
                cursor: not-allowed;
                transform: none;
                box-shadow: none;
            }
            .status {
                margin-top: 20px;
                padding: 15px;
                background: white;
                border-radius: 8px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                max-width: 90%;
                width: 400px;
                text-align: center;
                font-weight: bold;
                white-space: pre-wrap;
                line-height: 1.5;
            }
            .status-detail {
                margin-top: 15px;
                font-size: 14px;
                color: #555;
                font-weight: normal;
            }
        </style>
        <script>
            let pollingInterval = null;

            async function triggerRun() {
                const btn = document.querySelector('.btn');
                btn.disabled = true;
                
                try {
                    await fetch('/run', { method: 'POST' });
                    startPolling();
                } catch (error) {
                    console.error("Error:", error);
                    document.getElementById('status-msg').innerText = "❌ エラーが発生しました: " + error;
                    btn.disabled = false;
                }
            }
            
            async function fetchStatus() {
                try {
                    const response = await fetch('/status');
                    const data = await response.json();
                    
                    const statusDiv = document.getElementById('status-msg');
                    statusDiv.innerText = data.message;
                    statusDiv.style.color = data.color;
                    
                    const btn = document.querySelector('.btn');
                    if (data.isRunning) {
                        btn.disabled = true;
                        btn.innerHTML = "処理中...<br><span style='font-size:12px; font-weight:normal;'>(お待ちください)</span>";
                    } else {
                        btn.disabled = false;
                        btn.innerHTML = "実行<br>START";
                        // If it is finished and not running, stop polling after a successful status
                        if (pollingInterval && !data.isRunning && data.message !== "待機中") {
                            clearInterval(pollingInterval);
                            pollingInterval = null;
                        }
                    }
                } catch (error) {
                    console.error("Status fetch error:", error);
                }
            }

            function startPolling() {
                if (!pollingInterval) {
                    fetchStatus(); // immediate 
                    pollingInterval = setInterval(fetchStatus, 3000); // 3 seconds
                }
            }

            // 初期ロード時に状態チェック
            window.onload = startPolling;
        </script>
    </head>
    <body>
        <h1>会議録画アップロード (v2)</h1>
        <div class="subtitle">※長い動画（1時間以上）の場合、完了まで5〜10分ほどかかります</div>
        
        <button class="btn" onclick="triggerRun()">
            実行<br>START
        </button>
        
        <div class="status">
            <div id="status-msg" style="color: #666;">状態を確認中...</div>
            <div class="status-detail"><a href="/logs" target="_blank" style="color:#007bff; text-decoration:none;">📝 詳細な動作ログを確認する</a></div>
        </div>
        
        <div style="margin-top: 20px; font-size: 12px; color: #999;">
            他のPC・スマホからアクセス: <span id="access-url">...</span>
        </div>
        <script>
            document.getElementById('access-url').innerText = window.location.href;
        </script>
    </body>
    </html>
    """
    return html_content

@app.post("/run")
async def run_process(background_tasks: BackgroundTasks):
    global is_running
    if not is_running:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write("\n\n============================\n")
            f.write(" NEW RUN INITIATED VIA REMOTE \n")
            f.write("============================\n")
        background_tasks.add_task(run_script)
    return JSONResponse({"status": "started"})

@app.get("/status")
async def get_status():
    global is_running
    
    status_msg = "待機中"
    color = "#666"
    
    if os.path.exists(LOG_FILE):
        try:
            # 最新の200行を取得して直近の動向を判定
            with open(LOG_FILE, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()[-200:]
            
            content = "".join(lines)
            
            # Find the last NEW RUN marker index if available to avoid reading old runs
            run_marker = "NEW RUN INITIATED VIA REMOTE"
            if run_marker in content:
                content = content[content.rfind(run_marker):]

            if is_running:
                status_msg = "🔄 処理を開始しています...\n(PC側の準備中)"
                color = "#007bff"
                
                if "--- Step 3: Google Drive Upload ---" in content:
                    status_msg = "🟡 [3/3] Google Driveへ保存中...\nまもなく完了します！"
                    color = "#fd7e14"
                elif "--- Step 2: Gemini Minutes ---" in content:
                    status_msg = "🟡 [2/3] AI(Gemini)で議事録を作成中...\n数分かかる場合があります"
                    color = "#fd7e14"
                elif "--- Step 1: YouTube Upload ---" in content:
                    status_msg = "🟡 [1/3] YouTubeへ動画をアップロード中...\n動画の長さによっては5分程度かかります"
                    color = "#fd7e14"
                elif "Starting automatic processing" in content or "Downloading " in content:
                    status_msg = "🟡 [0/3] Zoom録画データの取得・準備中..."
                    color = "#17a2b8"
            else:
                # 実行していない場合の結果判定
                if "SUCCESS! Minutes saved to:" in content or "Drive Upload Success" in content or "YouTube Upload Success" in content:
                    status_msg = "✅ 前回の処理は正常に完了しました！"
                    color = "#28a745"
                elif "[SERVER ERROR]" in content or "Failed" in content or "Error:" in content:
                    status_msg = "❌ 前回エラーが発生しました（詳細ログを確認してください）"
                    color = "#dc3545"
                else:
                    status_msg = "待機中"
                    color = "#666"
        except Exception:
            pass
            
    return JSONResponse({
        "isRunning": is_running,
        "message": status_msg,
        "color": color
    })

@app.get("/logs", response_class=HTMLResponse)
async def show_logs():
    """process.logの最新300行を表示する"""
    log_content = "(ログファイルが見つかりません)"
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        # 最新300行
        last_lines = lines[-300:]
        log_content = ''.join(last_lines)
    
    html = f"""<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>処理ログ</title>
    <meta http-equiv="refresh" content="10"><!-- 10秒ごとに自動更新 -->
    <style>
        body {{ font-family: monospace; background: #1e1e1e; color: #d4d4d4; padding: 20px; }}
        h1 {{ color: #4fc3f7; }}
        pre {{ background: #2d2d2d; padding: 15px; border-radius: 8px; overflow-x: auto; white-space: pre-wrap; font-size: 13px; }}
        .error {{ color: #f48771; }}
        .success {{ color: #89d185; }}
        a {{ color: #4fc3f7; }}
    </style>
</head>
<body>
    <h1>📋 処理ログ（最新300行）</h1>
    <p>10秒ごとに自動更新 | <a href="/">← リモコンに戻る</a></p>
    <pre>{log_content}</pre>
</body>
</html>"""
    return html

if __name__ == "__main__":
    import uvicorn
    import socket
    
    def get_local_ip():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # doesn't even have to be reachable
            s.connect(('10.255.255.255', 1))
            IP = s.getsockname()[0]
        except Exception:
            IP = '127.0.0.1'
        finally:
            s.close()
        return IP

    local_ip = get_local_ip()
    url = f"http://{local_ip}:8000"
    
    # Listen on 0.0.0.0 to allow LAN access
    print("Starting Remote Control Server...")
    print(f"Access URL: {url}")
    uvicorn.run(app, host="0.0.0.0", port=8000)
