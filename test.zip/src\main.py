import sys
import os
import yaml
import logging
import requests
from datetime import datetime, timedelta
from services.zoom import ZoomClient
from services.processor import process_video_file

# Setup paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Configure Logging (File + Console)
log_file = os.path.join(BASE_DIR, 'process.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def load_secrets():
    with open(os.path.join(BASE_DIR, 'config', 'secrets.yaml'), 'r') as f:
        return yaml.safe_load(f)

def main():
    print("====================================")
    print("   Hearing App: Meeting Processor   ")
    print("====================================")
    
    try:
        secrets = load_secrets()
        zoom_conf = secrets['zoom']
        
        client = ZoomClient(
            zoom_conf['account_id'],
            zoom_conf['client_id'],
            zoom_conf['client_secret']
        )
        
        # 1. Fetch User Info (to get ID)
        print("Fetching user info...")
        token = client._get_access_token()
        users_resp = requests.get(
            "https://api.zoom.us/v2/users", 
            headers={"Authorization": f"Bearer {token}"}
        ).json()
        users = users_resp.get('users', [])
        
        if not users:
            print("No users found.")
            return

        target_user_id = users[0]['id']
        target_user_email = users[0]['email']
        print(f"User: {target_user_email}")

        # 2. List Recordings
        print("Fetching recordings list...")
        
        # Get recordings from the last 7 days
        seven_days_ago = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
        meetings = client.get_recordings(user_id=target_user_id, from_date=seven_days_ago)
        
        if not meetings:
            print("No recordings found in the last 7 days.")
            return
            
        # Sort by start_time to ensure we get the absolute latest
        meetings.sort(key=lambda x: x['start_time'])
        latest = meetings[-1]
        topic = latest.get('topic', 'No Topic')
        start_time = latest.get('start_time', 'Unknown')
        
        print(f"\n[Latest Recording Found]")
        print(f"  Topic: {topic}")
        print(f"  Time:  {start_time}")
        
        # 3. Find MP4 and Transcript
        download_url = None
        transcript_url = None
        
        for f in latest.get('recording_files', []):
            if f['file_type'] == 'MP4':
                download_url = f['download_url']
            elif f['file_type'] == 'TRANSCRIPT':  # Zoom VTT file
                transcript_url = f['download_url']
        
        if not download_url:
            print("No MP4 file found in this recording.")
            return

        # 4. Confirm (SKIPPED - Always Auto)
        print("\nStarting automatic processing...")
        choice = 'y'

        # 5. Download
        os.makedirs(os.path.join(BASE_DIR, 'data'), exist_ok=True)
        
        # 5a. Download MP4
        filename = f"{start_time}_{topic}.mp4".replace(':', '-').replace(' ', '_')
        save_path = os.path.join(BASE_DIR, 'data', filename)
        
        if os.path.exists(save_path):
            print(f"\nFile already exists: {save_path}")
            print("Using existing file (skipping download).")
        else:
            client.download_file(download_url, save_path)
            
        # 5b. Download Transcript (if available)
        transcript_path = None
        if transcript_url:
            transcript_filename = f"{start_time}_{topic}.vtt".replace(':', '-').replace(' ', '_')
            transcript_path = os.path.join(BASE_DIR, 'data', transcript_filename)
            try:
                print(f"Downloading transcript: {transcript_filename}...")
                logger.info(f"Downloading Transcript: {transcript_filename}")
                client.download_file(transcript_url, transcript_path)
                print("Transcript download complete.")
                logger.info("Transcript download complete.")
            except Exception as e:
                print(f"Transcript download failed: {e}")
                logger.error(f"Transcript download failed: {e}")
                transcript_path = None
        else:
            print("No transcript found for this recording.")
            logger.info("No transcript found for this recording.")
        
        # 6. Process (YouTube + Gemini [Transcript or Audio])
        process_video_file(save_path, base_dir=BASE_DIR, video_title=topic, transcript_path=transcript_path)

    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
