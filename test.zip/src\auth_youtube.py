
import os
import yaml
from services.youtube import YouTubeClient

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load_secrets():
    path = os.path.join(BASE_DIR, 'config', 'secrets.yaml')
    if os.path.exists(path):
        with open(path, 'r') as f:
            return yaml.safe_load(f)
    return {}

def main():
    print("====================================")
    print("   YouTube Re-Authentication Tool   ")
    print("====================================")
    print(f"Base Dir: {BASE_DIR}")
    
    client_secret = os.path.join(BASE_DIR, 'config', 'client_secret.json')
    token_file = os.path.join(BASE_DIR, 'config', 'token.pickle')
        
    if not os.path.exists(client_secret):
        print(f"Error: client_secret.json not found at {client_secret}")
        return

    print("Initializing YouTube Client...")
    yt = YouTubeClient(client_secret, token_file=token_file)
    
    print("Starting Authentication Flow...")
    print("A browser window should open shortly. Please log in with the NEW account.")
    
    try:
        service = yt.authenticate()
        print("\nSUCCESS! Authentication complete.")
        print(f"Token saved to: {token_file}")
    except Exception as e:
        print(f"\nFailed: {e}")

if __name__ == "__main__":
    main()
