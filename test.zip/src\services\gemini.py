import os
import time
import logging
import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold

class GeminiProcessor:
    def __init__(self, api_key, model_name="gemini-2.5-pro"):
        self.api_key = api_key
        self.model_name = model_name
        self.logger = logging.getLogger('GeminiProcessor')
        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel(self.model_name)

    def process_video(self, file_path, prompt_text=None):
        # 1. Upload
        self.logger.info(f"Uploading to Gemini: {file_path}")
        file_obj = genai.upload_file(file_path)
        self.logger.info(f"Uploaded: {file_obj.name}")

        # 2. Wait for processing
        self.logger.info("Waiting for processing...")
        while file_obj.state.name == "PROCESSING":
            time.sleep(5)
            file_obj = genai.get_file(file_obj.name)
        
        if file_obj.state.name == "FAILED":
            raise ValueError(f"Gemini processing FAILED. (Video might be too short/empty/unsupported)")

        # 3. Generate
        self.logger.info("Generating minutes...")
        if not prompt_text:
            prompt_text = "この動画の議事録を詳細に作成してください。"

        # Retry logic for 429 (Quota exceeded)
        max_retries = 5
        for attempt in range(max_retries):
            try:
                response = self.model.generate_content(
                    [file_obj, prompt_text],
                    request_options={"timeout": 600}
                )
                return response.text
            except Exception as e:
                is_quota_error = "429" in str(e) or "Quota exceeded" in str(e)
                if is_quota_error and attempt < max_retries - 1:
                    wait_time = 60  # Wait 60 seconds
                    self.logger.warning(f"Quota exceeded (429). Retrying in {wait_time}s... (Attempt {attempt+1}/{max_retries})")
                    time.sleep(wait_time)
                else:
                    raise e
