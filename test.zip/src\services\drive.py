import os
import logging
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

logger = logging.getLogger(__name__)

class DriveClient:
    def __init__(self, credentials, token_file='config/token.pickle'):
        self.creds = None
        self.token_file = token_file
        # Authenticate using the same credentials object or file
        # Ideally, we pass the credentials object directly if available, 
        # but existing code might rely on loading from pickle. 
        # For simplicity, let's reuse the loading logic or accept a ready creds object.
        self.creds = credentials

        self.service = build('drive', 'v3', credentials=self.creds)

    def upload_file(self, file_path, folder_id=None):
        """Uploads a file to Google Drive."""
        if not os.path.exists(file_path):
            print(f"File not found: {file_path}")
            return None

        file_metadata = {'name': os.path.basename(file_path)}
        if folder_id:
            file_metadata['parents'] = [folder_id]

        media = MediaFileUpload(file_path, resumable=True)

        try:
            print(f"Uploading to Drive: {os.path.basename(file_path)}...")
            file = self.service.files().create(
                body=file_metadata,
                media_body=media,
                fields='id, webViewLink'
            ).execute()
            
            file_id = file.get('id', '')
            web_link = file.get('webViewLink', '')
            print(f"Drive Upload Success. ID: {file_id}")
            return web_link
        
        except Exception as e:
            error_msg = str(e).encode('ascii', errors='replace').decode('ascii')
            print(f"Drive Upload Error: {error_msg}")
            logger.error(f"Drive Upload Error: {e}")
            return None
