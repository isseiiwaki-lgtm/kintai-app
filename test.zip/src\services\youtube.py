import os
import pickle
import logging
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

class YouTubeClient:
    SCOPES = ['https://www.googleapis.com/auth/youtube.upload', 'https://www.googleapis.com/auth/youtube.readonly', 'https://www.googleapis.com/auth/drive.file']
    
    def __init__(self, client_secret_file, token_file='config/token.pickle'):
        self.client_secret_file = client_secret_file
        self.token_file = token_file
        self.service = None
        self.logger = logging.getLogger('YouTubeClient')

    def authenticate(self):
        creds = None
        if os.path.exists(self.token_file):
            with open(self.token_file, 'rb') as token:
                creds = pickle.load(token)
        
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                    self.logger.info("トークンをリフレッシュしました。")
                    with open(self.token_file, 'wb') as token:
                        pickle.dump(creds, token)
                except Exception as e:
                    self.logger.error(f"トークンのリフレッシュに失敗しました: {e}")
                    creds = None
            
            if not creds:
                # バックグラウンド実行中は再認証できないのでエラーを発生させる
                raise RuntimeError(
                    "YouTube認証トークンが無効です。再認証が必要です。"
                    "ローカルで 再認証.py を実行してtoken.pickleを更新し、"
                    "GCPサーバーに転送してください。"
                )
        
        self.service = build('youtube', 'v3', credentials=creds)
        return self.service

    def upload_video(self, file_path, title, description, privacy_status='unlisted'):
        if not self.service:
            self.authenticate()

        body = {
            'snippet': {
                'title': title,
                'description': description,
                'tags': ['Zoom', 'Meeting', 'Automated'],
                'categoryId': '22'
            },
            'status': {
                'privacyStatus': privacy_status,
                'selfDeclaredMadeForKids': False
            }
        }

        media = MediaFileUpload(file_path, chunksize=-1, resumable=True)
        self.logger.info(f"Uploading {file_path} to YouTube ({privacy_status})...")
        
        request = self.service.videos().insert(
            part=','.join(body.keys()),
            body=body,
            media_body=media
        )

        response = None
        while response is None:
            status, response = request.next_chunk()
            if status:
                print(f"Upload progress: {int(status.progress() * 100)}%")

        self.logger.info(f"Upload complete! Video ID: {response['id']}")
        return response['id']
